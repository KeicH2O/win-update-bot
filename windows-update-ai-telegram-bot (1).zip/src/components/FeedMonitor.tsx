import React, { useState, useEffect } from 'react';
import { 
  Rss, 
  RefreshCw, 
  ExternalLink, 
  CheckCircle2, 
  AlertCircle, 
  Globe, 
  Layers, 
  Sparkles,
  PlusCircle,
  Trash2,
  Copy,
  Check,
  Edit3
} from 'lucide-react';

interface FeedSource {
  id: string;
  name: string;
  url: string;
  category: string;
  description: string;
  badgeColor: string;
  isCustom?: boolean;
}

const DEFAULT_SOURCES: FeedSource[] = [
  {
    id: 'ms-insider',
    name: 'Windows Insider Blog (Официальный блог Microsoft)',
    url: 'https://blogs.windows.com/windows-insider/feed/',
    category: 'Insider Build',
    description: 'Официальный блог команды Microsoft Insider. Сборки Canary, Dev, Beta и Release Preview с полным списком исправлений.',
    badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/30'
  },
  {
    id: 'ms-experience',
    name: 'Windows Experience Blog (Официальные релизы Windows 11)',
    url: 'https://blogs.windows.com/windowsexperience/feed/',
    category: 'Windows Release',
    description: 'Главные анонсы стабильных релизов Windows 11, функции ИИ Copilot и масштабные ежегодные обновления (24H2/25H2).',
    badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
  },
  {
    id: 'ms-security',
    name: 'Microsoft Security Blog (MSRC & Zero-Day)',
    url: 'https://www.microsoft.com/en-us/security/blog/feed/',
    category: 'Security / Zero-Day',
    description: 'Официальный бюллетень безопасности Microsoft: исправления "Вторника обновлений" (Patch Tuesday) и уязвимостей нулевого дня.',
    badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/30'
  },
  {
    id: 'azure-updates',
    name: 'Microsoft Azure Updates (Инфраструктура и облако)',
    url: 'https://azure.microsoft.com/en-us/updates/feed/',
    category: 'Cloud & Enterprise',
    description: 'Официальный фид обновлений облачной платформы Microsoft: службы виртуализации, Windows Server, контейнеры и безопасность.',
    badgeColor: 'bg-sky-500/20 text-sky-300 border-sky-500/30'
  },
  {
    id: 'pureinfotech',
    name: 'Pureinfotech (Каталог KB и логи патчей)',
    url: 'https://pureinfotech.com/feed/',
    category: 'Cumulative Update',
    description: 'Точные списки изменений всех накопительных обновлений, прямые ссылки на автономные пакеты .MSU и инструкции по откату.',
    badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-500/30'
  }
];

interface CustomSlot {
  id: string;
  name: string;
  url: string;
  category: string;
  description: string;
}

export const FeedMonitor: React.FC = () => {
  const [testingUrl, setTestingUrl] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<{ [key: string]: { ok: boolean; count?: number; error?: string } }>({});
  const [copiedCode, setCopiedCode] = useState(false);

  // 3 настраиваемых слота для ручной вставки RSS
  const [customSlots, setCustomSlots] = useState<CustomSlot[]>(() => {
    const saved = localStorage.getItem('custom_rss_slots');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return [
      {
        id: 'custom-1',
        name: 'Пользовательский источник #1',
        url: '',
        category: 'Custom Feed',
        description: 'Вставьте сюда URL любого RSS или Atom фида'
      },
      {
        id: 'custom-2',
        name: 'Пользовательский источник #2',
        url: '',
        category: 'Custom Feed',
        description: 'Вставьте сюда URL любого RSS или Atom фида'
      },
      {
        id: 'custom-3',
        name: 'Пользовательский источник #3',
        url: '',
        category: 'Custom Feed',
        description: 'Вставьте сюда URL любого RSS или Atom фида'
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('custom_rss_slots', JSON.stringify(customSlots));
  }, [customSlots]);

  const updateSlot = (index: number, field: keyof CustomSlot, val: string) => {
    setCustomSlots(prev => {
      const next = [...prev];
      next[index] = { ...next[index], [field]: val };
      return next;
    });
  };

  const clearSlot = (index: number) => {
    setCustomSlots(prev => {
      const next = [...prev];
      next[index] = {
        id: `custom-${index + 1}`,
        name: `Пользовательский источник #${index + 1}`,
        url: '',
        category: 'Custom Feed',
        description: 'Вставьте сюда URL любого RSS или Atom фида'
      };
      return next;
    });
    setTestResult(prev => {
      const next = { ...prev };
      delete next[`custom-${index + 1}`];
      return next;
    });
  };

  const testFeed = async (url: string, id: string) => {
    if (!url || !url.trim().startsWith('http')) {
      setTestResult(prev => ({
        ...prev,
        [id]: { ok: false, error: 'Укажите корректный URL (http:// или https://)' }
      }));
      return;
    }

    setTestingUrl(id);
    try {
      // 1. Попытка через встроенный серверный API эндпоинт приложения
      try {
        const localRes = await fetch(`/api/rss/test?url=${encodeURIComponent(url)}`, {
          signal: AbortSignal.timeout(9000)
        });
        if (localRes.ok) {
          const data = await localRes.json();
          if (data.ok && (data.count > 0 || data.sample)) {
            setTestResult(prev => ({
              ...prev,
              [id]: { ok: true, count: data.count || 1 }
            }));
            return;
          }
        }
      } catch (e) {
        // Fallback to external proxies
      }

      // 2. Попытка через rss2json
      try {
        const proxyUrl = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(url)}`;
        const res = await fetch(proxyUrl, { signal: AbortSignal.timeout(9000) });
        if (res.ok) {
          const data = await res.json();
          if (data.status === 'ok' && Array.isArray(data.items)) {
            setTestResult(prev => ({
              ...prev,
              [id]: { ok: true, count: data.items.length }
            }));
            return;
          }
        }
      } catch (e) {}

      // 3. Резервный быстрый прокси corsproxy.io
      try {
        const fallbackRes = await fetch(`https://corsproxy.io/?url=${encodeURIComponent(url)}`, {
          signal: AbortSignal.timeout(9000)
        });
        if (fallbackRes.ok) {
          const xml = await fallbackRes.text();
          const count = (xml.match(/<item[\s>]/gi) || xml.match(/<entry[\s>]/gi) || []).length;
          if (count > 0 || xml.includes('<rss') || xml.includes('<feed')) {
            setTestResult(prev => ({
              ...prev,
              [id]: { ok: true, count: Math.max(count, 1) }
            }));
            return;
          }
        }
      } catch (e) {}

      // 4. Резервный прокси allorigins
      try {
        const alloriginsRes = await fetch(`https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`, {
          signal: AbortSignal.timeout(9000)
        });
        if (alloriginsRes.ok) {
          const xml = await alloriginsRes.text();
          const count = (xml.match(/<item[\s>]/gi) || xml.match(/<entry[\s>]/gi) || []).length;
          if (count > 0 || xml.includes('<rss') || xml.includes('<feed')) {
            setTestResult(prev => ({
              ...prev,
              [id]: { ok: true, count: Math.max(count, 1) }
            }));
            return;
          }
        }
      } catch (e) {}

      throw new Error('Сервер RSS не ответил вовремя в браузере. В Cloudflare Worker лента будет опрашиваться напрямую с серверов.');
    } catch (err: any) {
      setTestResult(prev => ({
        ...prev,
        [id]: { 
          ok: false, 
          error: err.name === 'TimeoutError' || err.message?.includes('timed out') 
            ? 'Превышено время ожидания ответа сайта (таймаут)' 
            : (err.message || 'Ошибка загрузки RSS')
        }
      }));
    } finally {
      setTestingUrl(null);
    }
  };

  const testAllFeeds = async () => {
    for (const s of DEFAULT_SOURCES) {
      await testFeed(s.url, s.id);
    }
    for (const c of customSlots) {
      if (c.url.trim()) {
        await testFeed(c.url, c.id);
      }
    }
  };

  const copyCustomFeedsArray = () => {
    const all = [
      ...DEFAULT_SOURCES.map(s => ({ name: s.name, url: s.url, category: s.category })),
      ...customSlots.filter(c => c.url.trim()).map(c => ({ name: c.name, url: c.url, category: c.category }))
    ];

    const jsCode = `const RSS_FEEDS = ${JSON.stringify(all, null, 2)};`;
    navigator.clipboard.writeText(jsCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="space-y-8">
      
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-600 text-white shadow-lg">
              <Rss className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-100">Источники мониторинга Windows Update</h2>
              <p className="text-xs text-slate-400">
                Проверенные базовые ленты + 3 слота для добавления ваших собственных RSS источников.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={copyCustomFeedsArray}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition"
              title="Скопировать готовый массив RSS_FEEDS для worker.js"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedCode ? 'Скопировано!' : 'Копировать массив для Worker'}</span>
            </button>
            <button
              onClick={testAllFeeds}
              disabled={testingUrl !== null}
              className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-semibold rounded-xl shadow-lg transition"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${testingUrl ? 'animate-spin' : ''}`} />
              <span>Проверить все ленты</span>
            </button>
          </div>
        </div>
      </div>

      {/* РАЗДЕЛ 1: 3 ПОЛЬЗОВАТЕЛЬСКИХ СЛОТА ДЛЯ РУЧНОЙ ВСТАВКИ */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <PlusCircle className="w-5 h-5 text-emerald-400" />
            <h3 className="text-sm font-bold uppercase tracking-wider text-emerald-400">
              Ваши собственные RSS-источники (3 слота для ручной вставки)
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">Сохраняются в браузере автоматически</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {customSlots.map((slot, index) => {
            const isTesting = testingUrl === slot.id;
            const status = testResult[slot.id];
            const hasUrl = Boolean(slot.url.trim());

            return (
              <div
                key={slot.id}
                className={`bg-slate-900/90 border rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4 transition ${
                  hasUrl ? 'border-emerald-500/40 hover:border-emerald-500/70' : 'border-slate-800 border-dashed hover:border-slate-700'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      Слот #{index + 1}
                    </span>
                    {hasUrl && (
                      <button
                        onClick={() => clearSlot(index)}
                        className="text-slate-500 hover:text-red-400 transition text-xs p-1"
                        title="Очистить слот"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                      Название сайта / источника:
                    </label>
                    <input
                      type="text"
                      value={slot.name}
                      onChange={(e) => updateSlot(index, 'name', e.target.value)}
                      placeholder="Например: Comss.ru Windows Новости"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-xs text-slate-100 rounded-lg px-3 py-2 outline-none transition"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                      Прямая ссылка на RSS / XML ленту:
                    </label>
                    <input
                      type="url"
                      value={slot.url}
                      onChange={(e) => updateSlot(index, 'url', e.target.value)}
                      placeholder="https://example.com/feed.xml"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-xs text-emerald-300 font-mono rounded-lg px-3 py-2 outline-none transition"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                      Категория обновлений:
                    </label>
                    <select
                      value={slot.category}
                      onChange={(e) => updateSlot(index, 'category', e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 text-xs text-slate-300 rounded-lg px-3 py-2 outline-none"
                    >
                      <option value="Cumulative Update">Cumulative Update (Накопительные обновления)</option>
                      <option value="Insider Build">Insider Build (Инсайдерские сборки)</option>
                      <option value="Known Issue / Bug">Known Issue / Bug (Баги и сбои)</option>
                      <option value="Security / 0-Day">Security / 0-Day (Безопасность)</option>
                      <option value="Custom Feed">Custom Feed (Общая категория)</option>
                    </select>
                  </div>
                </div>

                {/* Status and Test Button for Custom Slot */}
                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                  <div className="text-xs truncate">
                    {status ? (
                      status.ok ? (
                        <span className="flex items-center gap-1 text-emerald-400 font-medium text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                          <span>Найдено: {status.count} шт</span>
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-red-400 font-medium text-[11px] truncate" title={status.error}>
                          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                          <span className="truncate">{status.error}</span>
                        </span>
                      )
                    ) : (
                      <span className="text-[11px] text-slate-500">Не тестировалась</span>
                    )}
                  </div>

                  <button
                    disabled={isTesting || !hasUrl}
                    onClick={() => testFeed(slot.url, slot.id)}
                    className="px-3 py-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 disabled:opacity-40 text-emerald-300 text-xs font-semibold rounded-lg border border-emerald-500/30 transition flex items-center gap-1 shrink-0"
                  >
                    <RefreshCw className={`w-3 h-3 ${isTesting ? 'animate-spin text-emerald-400' : ''}`} />
                    <span>{isTesting ? 'Тест...' : 'Тест RSS'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* РАЗДЕЛ 2: БАЗОВЫЕ ОФИЦИАЛЬНЫЕ ЛЕНТЫ */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Globe className="w-5 h-5 text-sky-400" />
          <h3 className="text-sm font-bold uppercase tracking-wider text-sky-400">
            Официальные и профильные ленты Microsoft (По умолчанию)
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {DEFAULT_SOURCES.map((source) => {
            const isTesting = testingUrl === source.id;
            const status = testResult[source.id];

            return (
              <div
                key={source.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between space-y-4 hover:border-slate-700 transition"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="p-1.5 rounded-lg bg-slate-800 text-slate-300">
                        <Globe className="w-4 h-4 text-sky-400" />
                      </span>
                      <h3 className="text-sm font-bold text-slate-100">{source.name}</h3>
                    </div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${source.badgeColor}`}>
                      {source.category}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed mb-3">
                    {source.description}
                  </p>

                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-850 flex items-center justify-between text-[11px] font-mono text-slate-400">
                    <span className="truncate mr-2">{source.url}</span>
                    <a
                      href={source.url}
                      target="_blank"
                      rel="noreferrer"
                      className="text-sky-400 hover:text-sky-300 shrink-0"
                      title="Открыть RSS ленту"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>

                {/* Status and Test Button */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-800/80">
                  <div>
                    {status ? (
                      status.ok ? (
                        <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Лента активна (Найдено: {status.count} записей)</span>
                        </span>
                      ) : (
                        <span className="flex items-center gap-1.5 text-xs text-red-400 font-medium">
                          <AlertCircle className="w-4 h-4" />
                          <span>{status.error}</span>
                        </span>
                      )
                    ) : (
                      <span className="text-[11px] text-slate-500">Статус не проверялся</span>
                    )}
                  </div>

                  <button
                    disabled={isTesting}
                    onClick={() => testFeed(source.url, source.id)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition flex items-center gap-1"
                  >
                    <RefreshCw className={`w-3 h-3 ${isTesting ? 'animate-spin text-sky-400' : ''}`} />
                    <span>{isTesting ? 'Тест...' : 'Тест RSS'}</span>
                  </button>
                </div>

              </div>
            );
          })}
        </div>
      </div>

      {/* Подсказка по интеграции */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-3">
        <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400" /> Как использовать добавленные ссылки:
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          Вы можете ввести любые RSS/XML адреса в 3 верхних слота, нажать <b>«Тест RSS»</b> для мгновенной проверки их валидности, а затем нажать <b>«Копировать массив для Worker»</b>, чтобы одной вставкой обновить список <code>RSS_FEEDS</code> в вашем коде <code>worker.js</code>.
        </p>
      </div>

    </div>
  );
};

